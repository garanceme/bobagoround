# Sudoku_PCA
  Sudoku solver with recursive Python and backtracking algorithm
